<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advertisement_1</title>
    <link rel="stylesheet" type="text/css" href="<?=ROOT?>/css/pdc/ad_1.css">
</head>
<body>
        <div class="details">
            <div class="compdetails">
                    <h4>Positions</h4>
                    <select>
                        <option value = "se">Sofware Engineer</option>
                        <option value = "qa">Quality Assuarance</option>
                        <option value = "ba">Business Analyst</option>
                    </select>
                    
                    <h4>Requirements</h4>
                    <input type = "text" class = "bx1">
                   
                    <h4>Qualifications</h4>
                    <input type = "text" class = "bx1">
                    
                    <h4>Internship Period</h4>
                    <div class = "card">
                        <div class = "input-container">
                            <input type = "text" class = "bx1">
                            <ion-icon name="calendar-outline" class = "calendar-icon"></ion-icon>
                        </div>
                        
                        <h4 class = "h4">to</h4>
                        
                        <div class = "input-container">
                            <input type = "text" class = "bx1">
                            <ion-icon name="calendar-outline" class = "calendar-icon"></ion-icon>
                        </div>
                    </div>

                    <div class = "card">
                        <h4>No. of Interns</h4>
                        <h4 class = "spaceleft">Working Mode</h4>
                    </div>
                    <div class = "card">
                        <input type = "text" class = "bx1">
                        <select>
                            <option value = "se">Online</option>
                            <option value = "qa">Physical</option>
                        </select>
                    </div>
                    
                    
                    
                    <div class="submit">
                        <button type="submit">SAVE</button>
                    </div>
            </div>
        </div>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>